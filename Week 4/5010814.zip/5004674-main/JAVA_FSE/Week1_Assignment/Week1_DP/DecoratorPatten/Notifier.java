package DecoratorPatten;

public interface Notifier {
    void send(String message);
}

