package ProxyPattern;

public interface Image {
    void display();
}
