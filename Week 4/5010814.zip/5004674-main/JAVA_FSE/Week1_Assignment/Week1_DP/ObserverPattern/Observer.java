package ObserverPattern;

public interface Observer {
    void update(double price);
}
