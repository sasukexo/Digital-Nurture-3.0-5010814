package FactoryMethodPattern;


    public interface Document {
        void create();
    }
    

