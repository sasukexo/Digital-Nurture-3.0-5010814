package StratergyPattern;

public interface PaymentStrategy {
    void pay(double amount);
}
