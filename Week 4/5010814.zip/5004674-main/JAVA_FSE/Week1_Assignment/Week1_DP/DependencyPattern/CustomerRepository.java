package DependencyPattern;

public class CustomerRepository {
    Customer findCustomerById(String id);
}
